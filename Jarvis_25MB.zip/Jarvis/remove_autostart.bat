@echo off
powershell -NoProfile -Command "Remove-Item ([Environment]::GetFolderPath('Startup')+'\Jarvis.lnk') -ErrorAction SilentlyContinue"
echo Jarvis will no longer start with Windows.
pause
