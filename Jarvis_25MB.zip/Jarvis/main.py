"""JARVIS - run with:  python main.py         (python main.py --mics  lists your microphones)"""
import re
import sys
import threading
import time
from types import SimpleNamespace

import config
from modules import tools
from modules.tools import (
    web_search, 
    upgrade_jarvis, 
    start_joke_timer, 
    record_mistake, 
    get_advice_for_mistake
)
from modules.speech import stream_sentences

REMEMBER = re.compile(r"^(?:hey |ok )?(?:jarvis[, ]*)?(?:please )?(?:remember|yaad rakho|save this)(?: that)?[: ,]*(.+)$", re.I)
RECALL = re.compile(r"what do you (?:remember|know about me)|what have i told you|mere bare me kya jaante|meri baatein batao", re.I)
FORGET_ALL = re.compile(r"forget (?:everything|all)|clear (?:your )?memory|sab bhool jao", re.I)
STOP_WORD = re.compile(r"^(?:jarvis[, ]*)?(?:stop|quiet|shut up|chup|ruko)[ .!]*$", re.I)
WRONG = re.compile(r"that was wrong|wrong answer|that'?s wrong|you misunderstood|not what i (?:asked|wanted)|galat", re.I)
LABELS = [("time", "time"), ("date", "date"), ("open", "open_target"), ("search", "search_web"), ("play", "play_youtube"),
         ("music", "play_youtube"), ("system", "system_status"), ("status", "system_status"), ("joke", "joke"),
         ("question", "ask_ai"), ("ask", "ask_ai"), ("think", "deep_think"), ("hello", "greeting"), ("greeting", "greeting"),
         ("thank", "thanks"), ("automate", "agent_task"), ("exit", "exit"), ("hindi", "switch_hindi"),
         ("english", "switch_english"), ("who are you", "identity"), ("how are you", "how_are_you")]


def handle(text, c):
    """c = context with: intents, actions, brain, agent, memory, vision, speech. Returns (reply, quit_now)."""
    low = text.lower()
    if config.REQUIRE_WAKE_WORD:
        if config.WAKE_WORD not in low:
            return None, False
        text = re.sub(config.WAKE_WORD, "", text, flags=re.I).strip(" ,.") or "hello"
        low = text.lower()

    # 0) Custom Commands: Upgrade & Internet Web Search
    if "upgrade" in low:
        return upgrade_jarvis(), False
    if "search for" in low or "look up" in low:
        query = low.replace("search for", "").replace("look up", "").strip()
        search_results = web_search(query)
        prompt = f"The user asked to look up: '{query}'. Here is live web data found: {search_results}. Answer the user naturally based on this."
        return stream_sentences(c.brain.ask_stream(prompt, deep=False)), False

    # 1) memory
    m = REMEMBER.match(text.strip())
    if m:
        c.memory.add(m.group(1))
        c.brain.facts = c.memory.facts
        return "Got it. I will remember that.", False
    if RECALL.search(low):
        if not c.memory.facts:
            return "I don't remember anything about you yet. Say: remember that, and then tell me.", False
        return "Here is what I remember. " + ". ".join(c.memory.facts[-10:]), False
    if FORGET_ALL.search(low):
        c.memory.clear()
        c.brain.facts = []
        return "Done. My memory is wiped.", False
    if STOP_WORD.match(text.strip()):
        return "Okay.", False

    # 2) everyday tools: timers, reminders, notes, weather, news
    reply = tools.route(text, c.speech.lang)
    if reply:
        return reply, False

    # 3) eyes: screen / camera
    from modules.vision import CAMERA, SCREEN
    if SCREEN.search(low):
        return c.vision.screen(text), False
    if CAMERA.search(low):
        return c.vision.camera(text), False

    # 4) the neural network decides everything else
    force_deep = re.search(r"think (deeply|hard|carefully|step by step)|deep think|deeply analy|gehraai", low)
    intent, conf = c.intents.predict(text)
    print(f"[Neural network] intent={intent} confidence={conf:.2f}")
    c.last = (text, intent)

    if force_deep:
        intent = "deep_think"
    if c.agent and ((intent == "agent_task" and conf >= config.CONFIDENCE_THRESHOLD) or c.agent.is_request(text)):
        return c.agent.run(text), False
    if "shut down completely" in low or "turn off jarvis" in low:
        return "Shutting down. Goodbye.", True
    if intent not in ("ask_ai", "deep_think") and conf >= config.CONFIDENCE_THRESHOLD:
        reply = c.actions.run(intent, text)
        if reply:
            return reply, False
            
    # Fast streaming response from Gemini brain
    return stream_sentences(c.brain.ask_stream(text, deep=(intent == "deep_think"))), False


def assistant_loop(bridge):
    from modules.actions import Actions
    from modules.agent import Agent
    from modules.brain import Brain
    from modules.intent_model import IntentModel
    from modules.memory import Memory
    from modules.speech import Speech
    from modules.vision import Vision

    bridge.caption.emit("Loading neural network...")
    intents = IntentModel()
    brain = Brain()
    speech = Speech()
    speech.on_level = bridge.level.emit           # rings move with your real voice
    memory = Memory()
    brain.facts = memory.facts

    def say(text):                                # speak + show on the HUD
        bridge.state.emit("speaking")
        bridge.caption.emit(f"Jarvis: {text}")
        bridge.log.emit(f"Jarvis: {text}")
        speech.speak(text)
        bridge.state.emit("listening")

    # Start background thread for 2-minute mixed jokes
    start_joke_timer(say)

    def status(text):                              # show progress only
        bridge.state.emit("thinking")
        bridge.caption.emit(text)

    c = SimpleNamespace(intents=intents, actions=Actions(speech), brain=brain, agent=Agent(brain, speech, say, status),
                        memory=memory, vision=Vision(brain), speech=speech, last=None)

    say("Hello, I am Jarvis. All systems online.")

    while True:
        for alert in tools.pop_alerts():         # timers / reminders that just finished
            say(alert)
        bridge.state.emit("listening")
        bridge.caption.emit("Listening...")
        
        t_heard = time.time()
        text = speech.listen()
        if not text:
            continue
            
        bridge.state.emit("thinking")
        bridge.caption.emit(f"You: {text}")
        bridge.log.emit(f"You: {text}")

        low = text.lower()

        # Handle user pointing out a mistake & learning from it
        if WRONG.search(text) or "that was wrong" in low or "wrong answer" in low or "galat" in low:
            wrong_text = c.last[0] if c.last else "recent action"
            say("My apologies, sir. What should I have done instead?")
            correct = speech.listen()
            if correct:
                advice = record_mistake(wrong_text, "incorrect_response", correct)
                say(advice)
            continue

        # Check self-advice for mistakes prior to answering
        advice = get_advice_for_mistake(text)
        if "My advice to myself is:" in advice:
            print(f"[Jarvis Self-Advice] {advice}")

        reply, quit_now = handle(text, c)
        if reply is None:
            continue

        # Handle streaming responses vs static text responses
        if hasattr(reply, "__next__") or hasattr(reply, "__iter__") and not isinstance(reply, str):
            collected = []
            def sentences_gen():
                for s in reply:
                    if not collected:
                        bridge.state.emit("speaking")
                        print(f"[Timing] first words after {time.time() - t_heard:.1f}s")
                    collected.append(s)
                    print(f"[Jarvis] {s}")
                    bridge.caption.emit(f"You: {text}\n\nJarvis: {' '.join(collected)}")
                    yield s
            speech.speak_stream(sentences_gen())
            reply_str = " ".join(collected) or "..."
            bridge.log.emit(f"Jarvis: {reply_str}")
            if quit_now:
                bridge.quit.emit()
                return
        else:
            bridge.state.emit("speaking")
            bridge.caption.emit(f"You: {text}\n\nJarvis: {reply}")
            bridge.log.emit(f"Jarvis: {reply}")
            speech.speak(reply)
            if quit_now:
                bridge.quit.emit()
                return


def main():
    if "--mics" in sys.argv:
        from modules.speech import list_microphones
        list_microphones()
        return

    from PyQt6.QtWidgets import QApplication
    from modules.gui import Bridge, HudWidget

    app = QApplication(sys.argv)
    hud, bridge = HudWidget(), Bridge()
    bridge.state.connect(hud.set_state)
    bridge.caption.connect(hud.set_caption)
    bridge.level.connect(hud.set_level)
    bridge.log.connect(hud.add_log)
    bridge.quit.connect(app.quit)
    from modules import speech as speech_module
    hud.on_stop = speech_module.stop_speaking      # SPACE or double-click stops Jarvis talking
    hud.resize(950, 950)
    hud.show()

    def runner():
        try:
            assistant_loop(bridge)
        except Exception as e:
            import traceback
            traceback.print_exc()
            bridge.caption.emit(f"Error: {e}")

    threading.Thread(target=runner, daemon=True).start()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()