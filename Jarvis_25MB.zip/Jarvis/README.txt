================================================================================
                              J A R V I S
                    Your personal voice AI assistant
================================================================================

WHAT IS THIS?
-------------
Jarvis is a local voice-controlled AI assistant for Windows that can:
  • Answer questions using Google Gemini
  • Open apps, search the web, play YouTube
  • Control the mouse/keyboard and look at your screen
  • Understand voice commands in English & Hindi
  • Remember things you tell it
  • Build things in Minecraft by watching a video

--------------------------------------------------------------------------------
1. INSTALLATION (Windows)
--------------------------------------------------------------------------------

1. Install Python 3.10 or 3.11 or 3.12 from:
   https://www.python.org/downloads/
   (IMPORTANT: check the box "Add Python to PATH" during install)

2. Open Command Prompt or PowerShell in this folder and run:

   pip install -r requirements.txt

3. Get a FREE Gemini API key:
   • Go to https://aistudio.google.com/apikey
   • Create a key
   • Open config.py in Notepad
   • Replace PASTE_YOUR_GEMINI_API_KEY_HERE with your key

4. (Optional but recommended) Install a microphone and speakers/headphones.

--------------------------------------------------------------------------------
2. HOW TO START
--------------------------------------------------------------------------------

• Easiest way: double-click  start_jarvis.bat

• Or from terminal:
   python main.py

• To see available microphones:
   python main.py --mics

• To run silently in background:
   double-click  start_silent.vbs

--------------------------------------------------------------------------------
3. FIRST TIME SETUP
--------------------------------------------------------------------------------

• Put your Gemini API key in config.py (see step 3 above)
• Speak clearly near the microphone
• Say "Jarvis" if wake-word is enabled (default is off)
• Use headphones if you enable "any_speech" interrupt mode
  (otherwise Jarvis may hear himself talking)

--------------------------------------------------------------------------------
4. USEFUL COMMANDS YOU CAN SAY
--------------------------------------------------------------------------------

Basic
  "What time is it?" / "What's the date?"
  "How are you?" / "Who are you?" / "Tell me a joke"
  "Switch to Hindi" / "Switch to English"

Open & Search
  "Open Notepad / Chrome / YouTube / Calculator"
  "Search for best pizza near me"
  "Play despacito on YouTube"

System
  "How is my CPU?" / "System status"
  "Take a note buy milk" / "Read my notes" / "Clear notes"
  "Remember that my name is Alex" / "What do you remember?"

AI & Vision
  "What's on my screen?"
  "What am I holding?" (uses webcam)
  "Think deeply about black holes"
  "Explain quantum computing"

Agent (advanced)
  "Make a castle in Minecraft with the help of this video"
    (first copy a YouTube link or put an .mp4 in the videos folder)

Stop talking
  Press SPACE, double-click the Jarvis window, or just speak over him.

--------------------------------------------------------------------------------
5. RETRAIN THE BRAIN (optional)
--------------------------------------------------------------------------------

If Jarvis misunderstands you often:

  python train_model.py

You can also correct him by saying "that was wrong" and teaching the right intent.

--------------------------------------------------------------------------------
6. FILES YOU MAY WANT TO EDIT
--------------------------------------------------------------------------------

config.py          → API key, voice settings, wake word, etc.
data/intents.json  → training phrases for the neural network
data/memory.json   → things Jarvis has remembered

--------------------------------------------------------------------------------
7. REQUIREMENTS
--------------------------------------------------------------------------------

See requirements.txt for the full list.
Main ones: google-genai, SpeechRecognition, PyQt6, scikit-learn, edge-tts, etc.

--------------------------------------------------------------------------------
8. NOTES
--------------------------------------------------------------------------------

• This package contains a reduced-size intent model (~20 MB) so the whole
  project fits in ~22-25 MB. Accuracy is still excellent.
• Never share your Gemini API key publicly.
• For best results use a good USB microphone and headphones.

Enjoy your Jarvis!
