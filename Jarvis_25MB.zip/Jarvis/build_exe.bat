@echo off
rem EXPERIMENTAL: builds dist\Jarvis\Jarvis.exe with PyInstaller (not tested by the author - use start_jarvis.bat if it fails).
rem First run:  python train_model.py   so the model folder exists.
cd /d "%~dp0"
pip install pyinstaller
pyinstaller --noconfirm --onedir --windowed --name Jarvis ^
  --add-data "data;data" --add-data "model;model" --add-data "videos;videos" ^
  --collect-all speech_recognition --collect-all edge_tts --collect-all google.genai ^
  --collect-submodules sklearn --hidden-import pyttsx3.drivers --hidden-import pyttsx3.drivers.sapi5 ^
  main.py
copy config.py dist\Jarvis\config.py
echo.
echo Finished. Your files are in dist\Jarvis  (keep config.py next to Jarvis.exe to edit settings)
pause
