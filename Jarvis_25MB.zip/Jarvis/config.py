"""All settings for Jarvis live here."""
import os

# ---- 1. GEMINI --------------------------------------------------------------
# Get a free key at https://aistudio.google.com/apikey  (never share it / upload it)
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "PASTE_YOUR_GEMINI_API_KEY_HERE")

# Jarvis tries these models in order and uses the first one your key can access.
# If Google renames models, just edit this list (see AI Studio for current names).
GEMINI_MODELS = ["gemini-3.8-flash", "gemini-3.5-flash", "gemini-2.5-flash"]

# ---- 2. MICROPHONE / VOICE --------------------------------------------------
# Run:  python main.py --mics   to see the numbers. None = Windows default mic.
MIC_INDEX = 1
LANGUAGE = "en-IN"          # "en-IN", "en-US" or "hi-IN" (you can also say "switch to Hindi")
SPEECH_RATE = 175           # speaking speed of the voice

# False = Jarvis answers everything he hears. True = only when you say "Jarvis ..."
REQUIRE_WAKE_WORD = False
WAKE_WORD = "jarvis"

# ---- 3. NEURAL NETWORK ------------------------------------------------------
# If the neural network is less sure than this, the question goes to Gemini instead.
CONFIDENCE_THRESHOLD = 0.55

# ---- 4. AGENT (Jarvis does work on your PC) ---------------------------------
# Path of your Minecraft launcher (leave "" if you open Minecraft yourself).
# Typical: r"C:\Program Files (x86)\Minecraft Launcher\MinecraftLauncher.exe"
MINECRAFT_LAUNCH = ""
# Put video files (mp4) here, OR copy a YouTube link to the clipboard before giving the command.
VIDEO_FOLDER = "videos"
AGENT_MAX_STEPS = 25        # safety limit for the screen-control loop

# ---- 5. VOICE & MEMORY (new) ------------------------------------------------
USE_NEURAL_VOICE = True              # natural Microsoft voice (free, needs internet). False = old Windows voice
TTS_VOICE_EN = "en-GB-RyanNeural"    # British male, very Jarvis. Others: en-IN-PrabhatNeural, en-US-GuyNeural
TTS_VOICE_HI = "hi-IN-MadhurNeural"  # Hindi male voice

# How you can interrupt Jarvis while he talks (use HEADPHONES, otherwise he hears himself):
#   "any_speech" = just start talking, he stops and listens to your new command
#   "stop_words" = he only stops for words like stop / quiet / chup / ruko
#   "off"        = only the SPACE key / double-click stops him
INTERRUPT_MODE = "any_speech"

# ---- 6. MORE NEW SETTINGS ---------------------------------------------------
STT_ENGINE = "google"        # "google" = online (default).  "whisper" = offline, much better for Hindi/Hinglish
WHISPER_MODEL = "small"      # tiny / base / small / medium  (bigger = more accurate but slower; first use downloads it)
DEFAULT_CITY = "Kanpur"      # used when you just say "what's the weather"
CAMERA_INDEX = 0             # webcam number for "what am I holding"
BACKUP_WORLD = True          # zip your Minecraft world before Jarvis builds
MINECRAFT_SAVES = ""         # leave "" for the normal Windows folder (%APPDATA%\\.minecraft\\saves)
