@echo off
rem Makes Jarvis start automatically when you log in to Windows (his microphone will then be on all the time).
powershell -NoProfile -Command "$s=(New-Object -COM WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Startup')+'\Jarvis.lnk'); $s.TargetPath='%~dp0start_silent.vbs'; $s.WorkingDirectory='%~dp0'; $s.Save()"
echo Done. Jarvis will start with Windows. Run remove_autostart.bat to undo.
pause
