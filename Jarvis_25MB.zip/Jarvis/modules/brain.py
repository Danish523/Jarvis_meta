"""Gemini brain: fast streaming answers + 'deep thinking' mode, with conversation memory."""
from google import genai
from google.genai import types

import config

SYSTEM = (
    "You are JARVIS, a witty, loyal and highly intelligent AI assistant like the one from Iron Man. "
    "Your answers are SPOKEN aloud, so: keep them short (1-3 sentences unless asked for more), "
    "no markdown, no bullet points, no emojis. "
    "If the user speaks Hindi (Devanagari) answer in Hindi; if they speak Hinglish answer in Hinglish. "
    "If you are not sure of a fact, say so instead of guessing."
)

DEEP_SYSTEM = (
    "You are JARVIS in DEEP THINKING mode. Reason carefully and step by step before answering: "
    "break the problem into parts, consider alternatives, double-check calculations and facts. "
    "Then give a clear final answer that sounds natural when spoken aloud: at most 6 short sentences, "
    "no markdown, no bullet points. Match the user's language (English / Hindi / Hinglish)."
)


class Brain:
    def __init__(self):
        self.ready = config.GEMINI_API_KEY and "PASTE" not in config.GEMINI_API_KEY
        self.client = genai.Client(api_key=config.GEMINI_API_KEY) if self.ready else None
        self.history = []          # conversation memory
        self.facts = []            # long-term memory facts
        self.model_i = 0
        self._kind_ok = {}
        self.last_error = ""

    def ask(self, text, deep=False):
        if not self.ready:
            return "Please paste your Gemini API key into config dot py, then restart me."
        self.history.append(self._user(text))
        answer = self._generate(self.history[-12:], deep)
        if answer:
            self._remember(answer)
            return answer
        self.history.pop()
        return self.last_error

    def ask_stream(self, text, deep=False):
        """Yields the answer in pieces AS GEMINI WRITES IT."""
        if not self.ready:
            yield "Please paste your Gemini API key into config dot py, then restart me."
            return
        self.history.append(self._user(text))
        produced = ""
        try:
            for chunk in self._stream(self.history[-12:], deep):
                produced += chunk
                yield chunk
            if not produced.strip():
                yield self.last_error
        finally:
            if produced.strip():
                self._remember(produced.strip())
            else:
                self.history.pop()

    def generate(self, contents, system, deep=False, json_mode=False):
        if not self.ready:
            self.last_error = "Please paste your Gemini API key into config dot py first."
            return None
        return self._generate(contents, deep, system=system, json_mode=json_mode)

    @staticmethod
    def _user(text):
        return types.Content(role="user", parts=[types.Part(text=text)])

    def _remember(self, answer):
        self.history.append(types.Content(role="model", parts=[types.Part(text=answer)]))
        self.history = self.history[-20:]

    def _system(self, system, deep):
        if system is not None:
            return system
        system = DEEP_SYSTEM if deep else SYSTEM
        if self.facts:
            system += ("\nThings the user told you earlier:\n- " + "\n- ".join(self.facts[-40:]))
        return system

    @staticmethod
    def _thinking(kind):
        try:
            if kind == "high":
                return types.ThinkingConfig(thinking_level="high")
            if kind == "low":
                return types.ThinkingConfig(thinking_level="low")
            if kind == "budget0":
                return types.ThinkingConfig(thinking_budget=0)
        except Exception:
            pass
        return None

    def _kinds(self, model, deep):
        base = ["high", None] if deep else ["low", "budget0", None]
        good = self._kind_ok.get((model, deep), "?")
        return ([good] if good != "?" else []) + [k for k in base if k != good]

    def _cfg(self, system, deep, kind, json_mode):
        kwargs = dict(system_instruction=system, temperature=0.4 if deep else 0.7)
        if json_mode:
            kwargs["response_mime_type"] = "application/json"
        elif not deep:
            kwargs["max_output_tokens"] = 800
        th = self._thinking(kind)
        if th is not None:
            kwargs["thinking_config"] = th
        return types.GenerateContentConfig(**kwargs)

    def _classify(self, e):
        msg, low = str(e), str(e).lower()
        if "429" in msg or "resource_exhausted" in low or "quota" in low:
            self.last_error = "I've reached the free Gemini limit for now. Please try again in a minute."
            return "stop"
        if "api key" in low or "api_key" in low or "permission" in low or "401" in msg or "403" in msg:
            self.last_error = "Gemini rejected my API key. Please check it in config dot py."
            return "stop"
        if "404" in msg or "not_found" in low or "not found" in low:
            return "model"
        return "retry"

    def _generate(self, contents, deep, system=None, json_mode=False):
        self.last_error = "Sorry, I couldn't think of an answer."
        system = self._system(system, deep)
        for i in range(self.model_i, len(config.GEMINI_MODELS)):
            model = config.GEMINI_MODELS[i]
            for kind in self._kinds(model, deep):
                try:
                    resp = self.client.models.generate_content(
                        model=model, contents=contents, config=self._cfg(system, deep, kind, json_mode))
                    self.model_i = i
                    self._kind_ok[(model, deep)] = kind
                    return (resp.text or "").strip() or None
                except Exception as e:
                    print(f"[Gemini:{model}] {str(e)[:200]}")
                    action = self._classify(e)
                    if action == "stop": return None
                    if action == "model": break
        self.last_error = "I couldn't reach Gemini. Check your internet connection."
        return None

    def _stream(self, contents, deep):
        self.last_error = "Sorry, I couldn't think of an answer."
        system = self._system(None, deep)
        for i in range(self.model_i, len(config.GEMINI_MODELS)):
            model = config.GEMINI_MODELS[i]
            for kind in self._kinds(model, deep):
                started = False
                try:
                    for chunk in self.client.models.generate_content_stream(
                            model=model, contents=contents, config=self._cfg(system, deep, kind, False)):
                        piece = chunk.text or ""
                        if piece:
                            started = True
                            yield piece
                    self.model_i = i
                    self._kind_ok[(model, deep)] = kind
                    return
                except Exception as e:
                    print(f"[Gemini:{model}] {str(e)[:200]}")
                    if started: return
                    action = self._classify(e)
                    if action == "stop": return
                    if action == "model": break
        self.last_error = "I couldn't reach Gemini."
        return None