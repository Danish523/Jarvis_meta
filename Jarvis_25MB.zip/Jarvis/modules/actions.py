"""Things Jarvis can DO on your computer."""
import datetime
import random
import re
import subprocess
import webbrowser
from urllib.parse import quote_plus

import psutil

APPS = {
    "notepad": "notepad", "calculator": "calc", "paint": "mspaint", "command prompt": "cmd",
    "file explorer": "explorer", "task manager": "taskmgr", "chrome": "chrome", "google chrome": "chrome",
    "word": "winword", "excel": "excel", "powerpoint": "powerpnt", "vs code": "code", "spotify": "spotify",
}
SITES = {
    "youtube": "https://www.youtube.com", "google": "https://www.google.com", "gmail": "https://mail.google.com",
    "github": "https://github.com", "whatsapp": "https://web.whatsapp.com", "instagram": "https://www.instagram.com",
    "facebook": "https://www.facebook.com", "linkedin": "https://www.linkedin.com", "netflix": "https://www.netflix.com",
    "maps": "https://maps.google.com", "chatgpt": "https://chatgpt.com", "gemini": "https://gemini.google.com",
}
JOKES = [
    "Why do programmers prefer dark mode? Because light attracts bugs.",
    "I would tell you a UDP joke, but you might not get it.",
    "Why did the neural network go to school? To improve its training.",
    "There are ten kinds of people: those who understand binary and those who don't.",
    "My code never has bugs. It just develops random features.",
]
HELLOS = ["Hello! How can I help?", "At your service.", "Hi there. What do you need?", "Online and ready."]
FINE = ["All systems running perfectly.", "Running at full power, thanks for asking.", "Doing great. What can I do for you?"]
YOURE_WELCOME = ["You're welcome.", "Always a pleasure.", "Anytime."]


def _strip_leading(text, pattern):
    return re.sub(pattern, "", text.strip(), flags=re.I).strip(" .?!")


class Actions:
    def __init__(self, speech):
        self.speech = speech

    def run(self, intent, text):
        """Returns the reply text, or None if Gemini should answer instead."""
        fn = getattr(self, f"do_{intent}", None)
        return fn(text) if fn else None

    def do_greeting(self, t):     return random.choice(HELLOS)
    def do_how_are_you(self, t):  return random.choice(FINE)
    def do_thanks(self, t):       return random.choice(YOURE_WELCOME)
    def do_joke(self, t):         return random.choice(JOKES)

    def do_identity(self, t):
        return ("I am Jarvis, your personal AI assistant. A neural network understands your commands, "
                "Gemini helps me think, and I can open apps, search the web, play music and check your system.")

    def do_time(self, t):
        return "It is " + datetime.datetime.now().strftime("%I:%M %p").lstrip("0")

    def do_date(self, t):
        return "Today is " + datetime.datetime.now().strftime("%A, %d %B %Y")

    def do_switch_hindi(self, t):
        self.speech.lang = "hi-IN"
        return "ठीक है, अब मैं हिंदी में बात करूँगा।"

    def do_switch_english(self, t):
        self.speech.lang = "en-IN"
        return "Alright, switching to English."

    def do_system_status(self, t):
        cpu = psutil.cpu_percent(interval=0.5)
        ram = psutil.virtual_memory().percent
        out = f"CPU is at {cpu:.0f} percent and memory is at {ram:.0f} percent."
        b = psutil.sensors_battery()
        if b:
            out += f" Battery is at {b.percent:.0f} percent" + (" and charging." if b.power_plugged else ".")
        return out

    def do_open_target(self, t):
        low = t.lower()
        for name in sorted(list(APPS) + list(SITES), key=len, reverse=True):
            if name in low:
                if name in APPS:
                    subprocess.Popen(f'start "" "{APPS[name]}"', shell=True)
                else:
                    webbrowser.open(SITES[name])
                return f"Opening {name}."
        m = re.search(r"([a-z0-9-]+\.(com|in|org|net|io))", low)
        if m:
            webbrowser.open("https://" + m.group(1))
            return f"Opening {m.group(1)}."
        return "I don't know that app yet. You can add it to the APPS list in actions dot py."

    def do_search_web(self, t):
        q = _strip_leading(t, r"^(hey |ok )?(jarvis )?(please )?(can you |could you )?(do a )?(search( the web| internet)?( for| on google for)?|google( search)?( for)?|look up|find( me)?)\s+")
        q = _strip_leading(q, r"\s+(on google|online|karo|kijiye)$")
        webbrowser.open("https://www.google.com/search?q=" + quote_plus(q or t))
        return f"Searching Google for {q or t}."

    def do_play_youtube(self, t):
        q = _strip_leading(t, r"^(hey |ok )?(jarvis )?(please )?(can you )?(play|put on|start playing|i want to listen to)\s+")
        q = _strip_leading(q, r"\s+(on youtube|chalao|play karo)$")
        q = re.sub(r"^(youtube pe |gana )", "", q).strip() or "music"
        webbrowser.open("https://www.youtube.com/results?search_query=" + quote_plus(q))
        return f"Playing {q} on YouTube."
