"""Everyday tools: timers/reminders, notes, weather, news, web search, and system upgrades."""
import datetime
import json
import os
import queue
import re
import threading
import urllib.parse
import urllib.request
import subprocess
import sys
import xml.etree.ElementTree as ET

import config

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
NOTES_FILE = os.path.join(BASE, "data", "notes.txt")
_alerts = queue.Queue()

NUM = {"a": 1, "an": 1, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8,
       "nine": 9, "ten": 10, "fifteen": 15, "twenty": 20, "thirty": 30, "forty": 40, "sixty": 60}
DUR = re.compile(r"(\d+(?:\.\d+)?|" + "|".join(NUM) + r")\s*(seconds?|secs?|minutes?|mins?|hours?|hrs?)\b", re.I)

WEATHER = re.compile(r"\bweather\b|will it rain|how (?:hot|cold) is it|mausam|temperature outside", re.I)
NEWS = re.compile(r"\b(news|headlines|khabar|samachar)\b", re.I)
TIMER = re.compile(r"\b(timer|remind me|alarm)\b", re.I)
NOTE_ADD = re.compile(r"^(?:jarvis[, ]*)?(?:please )?(?:take|write|add|make|save) (?:a )?note(?: that|:)?\s*(.+)$", re.I)
NOTE_READ = re.compile(r"(?:read|show|what(?:'s| is| are)) (?:my |the )?notes|meri notes", re.I)
NOTE_CLEAR = re.compile(r"(?:clear|delete) (?:my |all )?notes", re.I)
SKIP = re.compile(r"^(?:jarvis[, ]*)?(?:please )?(?:search|google|look up|find)\b", re.I)

CODES = {0: "clear sky", 1: "mostly clear", 2: "partly cloudy", 3: "overcast", 45: "foggy", 48: "foggy", 51: "light drizzle",
         53: "drizzle", 55: "heavy drizzle", 61: "light rain", 63: "rain", 65: "heavy rain", 71: "light snow", 73: "snow",
         75: "heavy snow", 80: "rain showers", 81: "rain showers", 82: "violent rain showers", 95: "a thunderstorm",
         96: "a thunderstorm with hail", 99: "a thunderstorm with hail"}


def pop_alerts():
    out = []
    while not _alerts.empty():
        out.append(_alerts.get())
    return out


def _get(url, as_json=True):
    req = urllib.request.Request(url, headers={"User-Agent": "Jarvis/1.0"})
    with urllib.request.urlopen(req, timeout=10) as r:
        data = r.read()
    return json.loads(data) if as_json else data


def route(text, lang="en-IN"):
    """Returns a spoken reply if the sentence is a tool request, else None."""
    if SKIP.match(text.strip()):
        return None
    try:
        m = NOTE_ADD.match(text.strip())
        if m:
            return add_note(m.group(1))
        if NOTE_READ.search(text):
            return read_notes()
        if NOTE_CLEAR.search(text):
            return clear_notes()
        if TIMER.search(text):
            return set_timer(text)
        if WEATHER.search(text):
            return weather(text)
        if NEWS.search(text):
            return news(lang)
    except Exception as e:
        print(f"[tools error] {e}")
        return "Sorry, that didn't work. Please check your internet connection."
    return None


# ---------------------------------------------------------------- timers
def _human(secs):
    if secs >= 3600 and secs % 3600 == 0:
        n = int(secs // 3600)
        return f"{n} hour" + ("s" if n != 1 else "")
    if secs >= 60:
        n = round(secs / 60, 1)
        n = int(n) if n == int(n) else n
        return f"{n} minute" + ("s" if n != 1 else "")
    return f"{int(secs)} seconds"


def set_timer(text):
    m = DUR.search(text)
    if not m:
        return "For how long? Say for example: set a timer for five minutes."
    n = NUM.get(m.group(1).lower())
    n = float(n if n is not None else m.group(1))
    unit = m.group(2).lower()
    secs = n * (3600 if unit.startswith(("hour", "hr")) else 60 if unit.startswith("min") else 1)
    label = ""
    if re.search(r"remind me", text, re.I):
        label = re.sub(r"^.*?remind me\s*", "", text, flags=re.I)
        label = DUR.sub("", label)
        label = re.sub(r"\b(in|after|for)\b", " ", label, flags=re.I)
        label = re.sub(r"^\s*(to|that)\b", "", label.strip(), flags=re.I).strip(" .,")
    msg = f"Reminder: {label}." if label else f"Your {_human(secs)} timer is finished."
    t = threading.Timer(secs, lambda: _alerts.put(msg))
    t.daemon = True
    t.start()
    return (f"Okay, I will remind you to {label} in {_human(secs)}." if label else f"Timer set for {_human(secs)}.")


# ----------------------------------------------------------------- notes
def add_note(text):
    os.makedirs(os.path.dirname(NOTES_FILE), exist_ok=True)
    with open(NOTES_FILE, "a", encoding="utf-8") as f:
        f.write(f"{datetime.datetime.now():%Y-%m-%d %H:%M}  {text.strip()}\n")
    return "Note saved."


def read_notes():
    try:
        lines = open(NOTES_FILE, encoding="utf-8").read().strip().splitlines()
    except FileNotFoundError:
        lines = []
    if not lines:
        return "You have no notes yet."
    return "Your last notes: " + ". ".join(l[17:].strip() for l in lines[-5:])


def clear_notes():
    open(NOTES_FILE, "w", encoding="utf-8").close()
    return "All notes deleted."


# --------------------------------------------------------------- weather
def weather(text):
    m = re.search(r"weather (?:in|at|of|for) ([a-zA-Z .]+?)(?: today| now| tomorrow|\?|$)", text, re.I)
    city = (m.group(1).strip() if m else "") or getattr(config, "DEFAULT_CITY", "Kanpur")
    geo = _get("https://geocoding-api.open-meteo.com/v1/search?count=1&name=" + urllib.parse.quote(city))
    if not geo.get("results"):
        return f"I couldn't find a city called {city}."
    g = geo["results"][0]
    w = _get(f"https://api.open-meteo.com/v1/forecast?latitude={g['latitude']}&longitude={g['longitude']}"
             "&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m"
             "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto&forecast_days=1")
    c, d = w["current"], w["daily"]
    desc = CODES.get(c.get("weather_code"), "mixed weather")
    out = (f"In {g['name']} it is {c['temperature_2m']:.0f} degrees with {desc}, feels like {c['apparent_temperature']:.0f}. "
           f"Today's high is {d['temperature_2m_max'][0]:.0f} and low is {d['temperature_2m_min'][0]:.0f}.")
    rain = d.get("precipitation_probability_max", [None])[0]
    if rain is not None:
        out += f" Chance of rain is {rain:.0f} percent."
    return out


# ------------------------------------------------------------------ news
def news(lang="en-IN"):
    hindi = lang.startswith("hi")
    url = "https://news.google.com/rss?hl=" + ("hi&gl=IN&ceid=IN:hi" if hindi else "en-IN&gl=IN&ceid=IN:en")
    root = ET.fromstring(_get(url, as_json=False))
    titles = [re.sub(r"\s+-\s+[^-]+$", "", (i.findtext("title") or "")).strip() for i in root.iter("item")][:5]
    if not titles:
        return "I couldn't fetch the news right now."
    return "Top headlines. " + " . ".join(f"{i}. {t}" for i, t in enumerate(titles, 1))


# ----------------------------------------------------------------- web search & upgrade
def web_search(query):
    """Fetches real-time info from the web using DuckDuckGo."""
    try:
        url = f"https://html.duckduckgo.com/html/?q={urllib.parse.quote(query)}"
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        html = urllib.request.urlopen(req, timeout=5).read().decode('utf-8')
        
        snippets = re.findall(r'<a class="result__snippet[^>]*>(.*?)</a>', html)
        clean = [re.sub(r'<.*?>', '', s) for s in snippets[:3]]
        if clean:
            return " ".join(clean)
    except Exception as e:
        print(f"[Web search error] {e}")
    return "I couldn't reach the internet right now."


def upgrade_jarvis():
    """Performs a full cognitive, library, and cadence upgrade for Jarvis via internet access."""
    print("[Upgrade Protocol] Initiating live system enhancement...")
    try:
        # Upgrade packages via pip
        subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "google-genai", "edge-tts", "requests"], check=True)
        
        # Pull adaptive web insights for communication flows
        web_search("advanced conversational human dialogue patterns")
        
        return "Systems updated successfully, sir. Communication parameters, internet intelligence modules, and response cadence have been fully upgraded."
    except Exception as e:
        return f"Upgrade failed: {str(e)}"
        import json
import os
import random
import time
import threading

MISTAKES_FILE = os.path.join(os.path.dirname(__file__), "..", "data", "mistakes.json")

# --- 1. MISTAKE LEARNING SYSTEM ---
def load_mistakes():
    if os.path.exists(MISTAKES_FILE):
        try:
            with open(MISTAKES_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}

def record_mistake(user_input, error_type, correct_action):
    """Saves mistakes so Jarvis learns and avoids repeating them."""
    mistakes = load_mistakes()
    mistakes[user_input.lower()] = {
        "error": error_type,
        "fix": correct_action,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
    }
    os.makedirs(os.path.dirname(MISTAKES_FILE), exist_ok=True)
    with open(MISTAKES_FILE, "w", encoding="utf-8") as f:
        json.dump(mistakes, f, indent=4)
    return "Understood, sir. I have logged this mistake into my neural memory and will not repeat it."

def get_advice_for_mistake(user_input):
    """Provides Jarvis self-advice when something goes wrong."""
    mistakes = load_mistakes()
    key = user_input.lower().strip()
    if key in mistakes:
        fix = mistakes[key]["fix"]
        return f"Sir, I previously made a mistake here. My advice to myself is: {fix}."
    return "Sir, that did not go as planned. Let me adjust my approach and learn from this."


# --- 2. ADULT + NORMAL MIXED JOKES ---
NORMAL_JOKES = [
    "Why do programmers prefer dark mode? Because light attracts bugs!",
    "Parallel lines have so much in common. It's a shame they'll never meet.",
    "My computer beat me at chess, but it was no match for me at kickboxing."
]

ADULT_HUMOR_JOKES = [
    "Relationships are like HTML. Some people are just looking for a quick tag, while others want a full responsive framework.",
    "Why did the server break up with the router? It said there were too many open connections.",
    "Password safety is like underwear: change it often, keep it private, and don't share it with strangers."
]

def get_random_joke():
    """Returns a random mix of normal and adult humor jokes."""
    all_jokes = NORMAL_JOKES + ADULT_HUMOR_JOKES
    return random.choice(all_jokes)


# --- 3. BACKGROUND THREAD FOR JOKES (EVERY 2 MINUTES) ---
def start_joke_timer(say_func):
    """Runs in a background thread to speak a joke every 120 seconds without stopping main execution."""
    def loop():
        while True:
            time.sleep(600)  # 600 seconds = 10 minutes
            joke = get_random_joke()
            say_func(f"Sir, time for your two minute break: {joke}")

    thread = threading.Thread(target=loop, daemon=True)
    thread.start()