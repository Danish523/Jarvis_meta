"""Iron-Man style HUD: real 3D rotating rings (rotation + perspective projection), drawn with PyQt6."""
import math
import random

from PyQt6.QtCore import QObject, QPointF, QRectF, Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QColor, QFont, QPainter, QPen, QRadialGradient, QTextOption, QBrush
from PyQt6.QtWidgets import QWidget

STATE_COLORS = {            # state -> (r, g, b)
    "idle": (0, 170, 255),
    "listening": (0, 255, 200),
    "thinking": (255, 170, 0),
    "speaking": (110, 210, 255),
}
STATE_SPEED = {"idle": 1.0, "listening": 1.3, "thinking": 3.2, "speaking": 1.8}
STATE_TEXT = {"idle": "STANDBY", "listening": "LISTENING", "thinking": "THINKING", "speaking": "SPEAKING"}

N = 120  # points per ring

# radius, tilt(x,y,z), spin speed(x,y,z), line width, style, glow, along-ring speed
RINGS = [
    (1.00, (1.25, 0.20, 0.0), (0.22, 0.10, 0.00), 2.2, "full", True, 0.0),
    (0.86, (0.40, 1.00, 0.0), (-0.15, 0.28, 0.10), 3.2, "arc", True, 0.6),
    (0.72, (1.00, -0.50, 0.3), (0.20, -0.24, 0.14), 1.6, "dash", False, -0.5),
    (0.58, (0.20, 0.30, 1.0), (-0.30, 0.20, 0.20), 4.2, "arc3", True, 0.9),
    (1.14, (1.45, 0.10, 0.0), (0.05, 0.18, 0.00), 1.4, "ticks", False, 0.15),
]
GLOBE = [(0.0, 0.0, 0.0), (1.0472, 0.0, 0.0), (2.0944, 0.0, 0.0), (0.0, 1.5708, 0.0)]  # tilted circles of the core


class Bridge(QObject):
    """Lets the assistant thread talk safely to the GUI."""
    state = pyqtSignal(str)
    caption = pyqtSignal(str)
    quit = pyqtSignal()
    level = pyqtSignal(float)     # live microphone volume 0..1
    log = pyqtSignal(str)         # a line for the scrolling log


def _rotate(p, ax, ay, az):
    x, y, z = p
    c, s = math.cos(ax), math.sin(ax)
    y, z = y * c - z * s, y * s + z * c
    c, s = math.cos(ay), math.sin(ay)
    x, z = x * c + z * s, -x * s + z * c
    c, s = math.cos(az), math.sin(az)
    x, y = x * c - y * s, x * s + y * c
    return x, y, z


class HudWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("J.A.R.V.I.S")
        self.setMinimumSize(640, 640)
        self.state = "idle"
        self.caption = "Initialising systems..."
        self.color = list(STATE_COLORS["idle"])
        self.t = 0.0
        self.speed = 1.0
        self.level = 0.0
        self.vx = 0.0          # view rotation (drag with the mouse)
        self.vy = 0.0
        self._last = None
        self.on_stop = None     # set by main.py
        self.mic_level = 0.0    # real microphone volume (smoothed)
        self._raw_level = 0.0
        self.log_lines = []
        self.stars = [(random.random(), random.random(), random.random()) for _ in range(70)]
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)
        self.timer.start(16)

    # ---- slots ---------------------------------------------------------------
    def set_state(self, s):
        self.state = s if s in STATE_COLORS else "idle"

    def set_caption(self, text):
        self.caption = text

    def set_level(self, v):
        self._raw_level = v

    def add_log(self, line):
        self.log_lines = (self.log_lines + [line])[-40:]

    # ---- input ---------------------------------------------------------------
    def mousePressEvent(self, e):
        self._last = e.position()

    def mouseMoveEvent(self, e):
        if self._last is not None and e.buttons() & Qt.MouseButton.LeftButton:
            d = e.position() - self._last
            self.vy += d.x() * 0.01
            self.vx += d.y() * 0.01
        self._last = e.position()

    def mouseDoubleClickEvent(self, e):
        if self.on_stop:
            self.on_stop()

    def keyPressEvent(self, e):
        if e.key() == Qt.Key.Key_Escape:
            self.close()
        elif e.key() == Qt.Key.Key_Space and self.on_stop:
            self.on_stop()
        elif e.key() == Qt.Key.Key_F11:
            self.showNormal() if self.isFullScreen() else self.showFullScreen()

    # ---- animation -----------------------------------------------------------
    def _tick(self):
        dt = 0.016
        self.speed += (STATE_SPEED[self.state] - self.speed) * 0.05
        self.t += dt * self.speed
        self.mic_level += (self._raw_level - self.mic_level) * 0.35     # smooth the real mic volume
        self._raw_level *= 0.9
        target = {"idle": 0.12, "listening": 0.15 + 0.85 * min(1.0, self.mic_level * 1.4),
                  "thinking": 0.5, "speaking": 0.35 + 0.65 * abs(math.sin(self.t * 7) * math.sin(self.t * 2.3 + 1))}[self.state]
        self.level += (target - self.level) * 0.15
        goal = STATE_COLORS[self.state]
        for i in range(3):
            self.color[i] += (goal[i] - self.color[i]) * 0.06
        self.vx *= 0.985       # drag rotation slowly settles
        self.vy *= 0.985
        self.update()

    # ---- 3D helpers ----------------------------------------------------------
    def _project(self, p, ax, ay, az, scale, cx, cy):
        x, y, z = _rotate(p, ax + self.vx, ay + self.vy, az)
        f = 3.4 / (3.4 + z)                      # perspective
        return cx + x * f * scale, cy + y * f * scale, z

    def _ring(self, painter, spec, t, scale, cx, cy, col):
        r, tilt, spin, width, style, glow, along = spec
        ax, ay, az = (tilt[i] + spin[i] * t for i in range(3))
        ax += 0.12 * math.sin(t * 0.6)
        pts = []
        for i in range(N):
            a = 2 * math.pi * i / N
            pts.append(self._project((r * math.cos(a), r * math.sin(a), 0.0), ax, ay, az, scale, cx, cy))
        shift = int(t * along * N / 6) % N

        if style == "ticks":
            for i in range(0, N, 1):
                a = 2 * math.pi * (i + shift * 0.2) / N
                long_tick = i % 5 == 0
                p1 = self._project((r * math.cos(a), r * math.sin(a), 0.0), ax, ay, az, scale, cx, cy)
                r2 = r * (1.09 if long_tick else 1.045)
                p2 = self._project((r2 * math.cos(a), r2 * math.sin(a), 0.0), ax, ay, az, scale, cx, cy)
                d = (p1[2] + r) / (2 * r)
                painter.setPen(QPen(QColor(*col, int(50 + 170 * d)), 1.6 if long_tick else 1.0))
                painter.drawLine(QPointF(p1[0], p1[1]), QPointF(p2[0], p2[1]))
            return

        def visible(i):
            k = (i + shift) % N
            if style == "full":
                return True
            if style == "dash":
                return (k // 4) % 2 == 0
            if style == "arc":
                return k < N * 0.68
            if style == "arc3":
                return (k * 3 / N) % 1 < 0.55
            return True

        for pass_ in ((3.4, 0.10), (1.0, 1.0)) if glow else ((1.0, 1.0),):
            wmul, amul = pass_
            for i in range(N):
                if not visible(i):
                    continue
                p1, p2 = pts[i], pts[(i + 1) % N]
                d = ((p1[2] + p2[2]) / 2 + r) / (2 * r)          # 0 (far) .. 1 (near)
                alpha = int((60 + 195 * d) * amul)
                painter.setPen(QPen(QColor(*col, min(alpha, 255)), width * wmul * (0.65 + 0.7 * d)))
                painter.drawLine(QPointF(p1[0], p1[1]), QPointF(p2[0], p2[1]))

        if style in ("arc", "dash"):          # little orbiting satellite
            a = t * 1.7 * (1 if along > 0 else -1)
            x, y, z = self._project((r * math.cos(a), r * math.sin(a), 0.0), ax, ay, az, scale, cx, cy)
            d = (z + r) / (2 * r)
            rad = 3 + 5 * d
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QBrush(QColor(255, 255, 255, int(120 + 135 * d))))
            painter.drawEllipse(QPointF(x, y), rad, rad)

    # ---- drawing ---------------------------------------------------------------
    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()
        cx, cy = w / 2, h * 0.46
        scale = min(w, h) * 0.30
        col = tuple(int(c) for c in self.color)

        bg = QRadialGradient(QPointF(cx, cy), max(w, h) * 0.7)
        bg.setColorAt(0.0, QColor(8, 26, 46))
        bg.setColorAt(1.0, QColor(2, 5, 12))
        p.fillRect(self.rect(), QBrush(bg))

        p.setPen(Qt.PenStyle.NoPen)                           # twinkling background dust
        for sx, sy, ss in self.stars:
            tw = 0.5 + 0.5 * math.sin(self.t * 2 + ss * 20)
            p.setBrush(QColor(col[0], col[1], col[2], int(30 + 80 * tw)))
            p.drawEllipse(QPointF(sx * w, sy * h), 1 + ss * 1.5, 1 + ss * 1.5)

        # glowing core
        core_r = scale * (0.17 + 0.10 * self.level)
        g = QRadialGradient(QPointF(cx, cy), core_r * 2.6)
        g.setColorAt(0.0, QColor(255, 255, 255, 235))
        g.setColorAt(0.25, QColor(*col, 210))
        g.setColorAt(1.0, QColor(*col, 0))
        p.setBrush(QBrush(g))
        p.drawEllipse(QPointF(cx, cy), core_r * 2.6, core_r * 2.6)

        # wireframe globe inside the core
        p.setBrush(Qt.BrushStyle.NoBrush)
        for gt in GLOBE:
            pts = []
            for i in range(60):
                a = 2 * math.pi * i / 60
                pts.append(self._project((0.30 * math.cos(a), 0.30 * math.sin(a), 0.0),
                                         gt[0] + self.t * 0.8, gt[1] + self.t * 1.1, gt[2], scale, cx, cy))
            for i in range(60):
                a, b = pts[i], pts[(i + 1) % 60]
                d = ((a[2] + b[2]) / 2 + 0.3) / 0.6
                p.setPen(QPen(QColor(*col, int(70 + 150 * d)), 1.3))
                p.drawLine(QPointF(a[0], a[1]), QPointF(b[0], b[1]))

        # the big 3D rings (far ones first is not needed because of alpha-by-depth)
        for spec in RINGS:
            self._ring(p, spec, self.t, scale * (1 + 0.04 * self.level), cx, cy, col)

        # text
        p.setPen(QColor(*col))
        f = QFont("Segoe UI", max(16, int(min(w, h) * 0.04)), QFont.Weight.Bold)
        f.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, 10)
        p.setFont(f)
        p.drawText(QRectF(0, h * 0.02, w, h * 0.09), Qt.AlignmentFlag.AlignCenter, "J.A.R.V.I.S")

        f2 = QFont("Consolas", max(10, int(min(w, h) * 0.02)))
        f2.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, 4)
        p.setFont(f2)
        p.drawText(QRectF(0, cy + scale * 1.28, w, 30), Qt.AlignmentFlag.AlignCenter, f"●  {STATE_TEXT[self.state]}")

        p.setPen(QColor(210, 235, 255, 230))
        p.setFont(QFont("Segoe UI", max(10, int(min(w, h) * 0.022))))
        opt = QTextOption(Qt.AlignmentFlag.AlignHCenter)
        opt.setWrapMode(QTextOption.WrapMode.WordWrap)
        p.drawText(QRectF(w * 0.1, cy + scale * 1.28 + 40, w * 0.8, h - (cy + scale * 1.28 + 50)), self.caption, opt)
        # scrolling conversation log (bottom-left)
        lf = QFont("Consolas", 9)
        p.setFont(lf)
        y = h - 14
        for line in reversed(self.log_lines[-8:]):
            txt = line if len(line) < 70 else line[:67] + "..."
            fade = 90 + int(120 * (1 - (h - 14 - y) / 130.0)) if y > h - 150 else 60
            p.setPen(QColor(*col, max(40, min(fade, 200))))
            p.drawText(QPointF(16, y), txt)
            y -= 16
        p.end()
