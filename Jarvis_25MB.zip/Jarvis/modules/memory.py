"""Long-term memory: facts you tell Jarvis are saved in data/memory.json (stays on your PC)."""
import json
import os

PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "memory.json")
MAX_FACTS = 100


class Memory:
    def __init__(self):
        self.facts = []
        try:
            with open(PATH, encoding="utf-8") as f:
                self.facts = [str(x) for x in json.load(f)]
        except Exception:
            self.facts = []

    def _save(self):
        os.makedirs(os.path.dirname(PATH), exist_ok=True)
        with open(PATH, "w", encoding="utf-8") as f:
            json.dump(self.facts, f, ensure_ascii=False, indent=2)

    def add(self, fact):
        fact = fact.strip(" .")
        if fact and fact.lower() not in (x.lower() for x in self.facts):
            self.facts.append(fact)
            self.facts = self.facts[-MAX_FACTS:]
            self._save()

    def clear(self):
        self.facts = []
        self._save()
