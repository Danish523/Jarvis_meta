"""Builds extra training sentences by combining sentence frames with topics (a bigger dataset)."""
import itertools
import random

APPS = ["notepad", "calculator", "chrome", "paint", "word", "excel", "powerpoint", "vs code", "spotify", "command prompt",
        "file explorer", "task manager", "youtube", "gmail", "github", "whatsapp", "instagram", "facebook", "linkedin", "google", "netflix", "maps"]
OPEN_FRAMES = ["open {}", "launch {}", "start {}", "please open {}", "jarvis open {}", "can you open {}", "run {}", "{} kholo", "{} open karo", "{} khol do", "bring up {}", "i want to use {}"]

SEARCH_TOPICS = ["python tutorials", "best phones", "nearest restaurant", "latest cricket score", "news today", "cheap flights", "online courses", "weather forecast",
                 "hindi songs", "job openings", "electric cars", "laptop reviews", "movie tickets", "train timings", "stock market news", "pizza recipe", "gym workouts"]
SEARCH_FRAMES = ["search for {}", "google {}", "look up {}", "search {} on google", "find {} online", "search the web for {}", "{} search karo", "google pe {} dhundo", "can you search for {}", "do a web search for {}"]

SONGS = ["despacito", "believer", "shape of you", "arijit singh", "lofi music", "kesariya", "relaxing music", "party songs", "old hindi songs", "taylor swift", "jazz", "rock music", "workout playlist", "punjabi songs"]
PLAY_FRAMES = ["play {}", "play {} on youtube", "put on {}", "i want to listen to {}", "{} chalao", "play some {}", "start playing {}", "youtube pe {} play karo"]

ASK_TOPICS = ["black holes", "the french revolution", "photosynthesis", "machine learning", "the solar system", "dna", "inflation", "the internet", "electricity",
              "world war two", "evolution", "the human heart", "volcanoes", "cryptocurrency", "gravity", "the moon", "rainbows", "democracy", "vitamins", "artificial intelligence", "the stock market", "mount everest", "the amazon rainforest"]
ASK_FRAMES = ["what is {}", "explain {}", "tell me about {}", "how does {} work", "why is {} important", "give me facts about {}", "can you explain {} simply", "what do you know about {}", "{} kya hai", "{} ke bare me batao", "who discovered {}", "describe {}"]

DEEP_TOPICS = ["starting a business", "learning to code", "climate change", "my career choices", "artificial intelligence", "investing money", "remote work", "social media",
               "a healthy lifestyle", "the future of education", "electric vehicles", "my exam preparation", "space exploration", "nuclear energy"]
DEEP_FRAMES = ["think deeply about {}", "analyze {} in depth", "think step by step about {}", "give me a detailed analysis of {}", "deep think about {}", "reason carefully about {}",
               "do a thorough analysis of {}", "think hard about {}", "carefully analyze the pros and cons of {}", "{} ke bare me gehraai se sochkar batao"]

AGENT_THINGS = ["a castle", "a house", "a big tower", "a bridge", "a pyramid", "a modern villa", "a medieval fortress", "a farm", "a treehouse", "a wall"]
AGENT_FRAMES = ["make {} in minecraft", "build {} in minecraft by following this video", "open minecraft and build {}", "jarvis build {} in minecraft with the help of this video",
                "start minecraft and make {}", "minecraft me {} banao", "create {} in minecraft using the following video", "play minecraft and construct {}"]

EXTRA = {
    "agent_task": ["do this task on my computer", "control my pc and do this work", "follow the video and do the work for me", "by the help of this video do the task", "use my computer to finish this job",
                   "automate this task for me", "do this work by watching the video", "take control of my screen and do it", "jarvis do the work for me", "follow this tutorial video and do it on my pc",
                   "mere computer pe ye kaam karo", "video dekh kar ye kaam karo"],
    "system_status": ["system status", "check cpu", "cpu usage", "ram usage", "battery level", "how much battery is left", "battery status", "is my pc fine", "check memory usage", "pc status report", "laptop battery kitni hai", "cpu check karo", "how is the system", "run system check", "system report please", "how much charge is left", "what's my battery at", "memory usage please", "computer health", "performance report", "system ka status batao", "show cpu and ram usage", "is my computer running okay", "battery check"],
    "joke": ["joke", "tell me a joke jarvis", "another joke", "tell me one more joke", "make me laugh jarvis", "say something funny jarvis", "i am bored tell me a joke", "funny joke please", "ek aur joke", "kuch funny sunao", "got any jokes", "humor me", "lighten the mood with a joke", "give me a funny line"],
    "thanks": ["thanks", "thank you", "thank you jarvis", "thanks buddy", "many thanks", "thanks for the help", "that's great thank you", "perfect thanks", "good job jarvis", "you are awesome", "you're the best", "much appreciated", "thanks a ton", "bahut shukriya", "thank u", "thx", "nice work", "excellent", "brilliant job", "wonderful thanks"],
    "exit": ["exit", "quit", "bye", "goodbye", "bye bye", "shutdown", "shut down now", "close the assistant", "stop listening", "go offline", "turn off", "that will be all", "see you tomorrow", "i am done for today", "end program", "sleep now jarvis", "band karo", "alvida", "chalo bye", "ok bye jarvis"],
    "greeting": ["hello jarvis how are you doing today", "good morning jarvis", "good evening jarvis", "hello there", "hi there jarvis", "hey jarvis", "morning", "evening", "good night", "hello again", "hey buddy", "jarvis wake up", "daddy's home jarvis", "welcome back", "hi", "hello hello", "hey assistant", "hola", "ram ram", "pranam"],
    "how_are_you": ["how are you jarvis", "how are you today", "how you doing", "how's your day", "how do you do", "are you feeling good", "what's going on", "how is life", "how are things", "kaisa hai tu", "sab theek", "aap theek ho", "how are you feeling", "you good", "how r u"],
    "time": ["what time is it jarvis", "time", "tell me current time", "what's the time right now", "kya time hua", "time batao", "what is the time please", "jarvis what time is it", "how late is it", "what's the clock say", "tell me what time it is", "current time please"],
    "date": ["date", "today's date", "what date is it", "which day today", "what is the day today", "tell me today's date jarvis", "aaj ki tarikh", "aaj kaun sa din hai", "what's today", "tell me the day", "which month is it", "what is the date and day"],
    "identity": ["who are you jarvis", "your name", "what's your name", "tell me who you are", "who built you", "what do you do", "what can you help me with", "tum kya kar sakte ho", "kya naam hai tumhara", "are you real", "introduce yourself jarvis", "what are you capable of"],
}


def expand(frames, items):
    return [f.format(i) for f, i in itertools.product(frames, items)]


def build(seed=1, per_intent=70):
    rng = random.Random(seed)
    groups = {
        "open_target": expand(OPEN_FRAMES, APPS),
        "search_web": expand(SEARCH_FRAMES, SEARCH_TOPICS),
        "play_youtube": expand(PLAY_FRAMES, SONGS),
        "ask_ai": expand(ASK_FRAMES, ASK_TOPICS),
        "deep_think": expand(DEEP_FRAMES, DEEP_TOPICS),
        "agent_task": expand(AGENT_FRAMES, AGENT_THINGS),
    }
    out = {}
    for k, v in groups.items():
        rng.shuffle(v)
        out[k] = v[:per_intent]
    for k, v in EXTRA.items():
        out[k] = list(v)
    return out
