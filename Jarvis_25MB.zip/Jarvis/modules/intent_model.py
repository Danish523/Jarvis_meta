"""
Neural network that understands WHAT you want (the "intent").

Pipeline:  text -> TF-IDF character n-grams -> MLP neural network (2 hidden layers) -> intent + confidence
Character n-grams make it tolerant to speech-recognition mistakes and Hinglish spelling.
"""
import json
import os
import random
import threading

import joblib
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import accuracy_score, classification_report
from sklearn.model_selection import StratifiedKFold, cross_val_score, train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import FeatureUnion, Pipeline

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_FILE = os.path.join(BASE, "data", "intents.json")
MODEL_FILE = os.path.join(BASE, "model", "intent_model.joblib")
USER_FILE = os.path.join(BASE, "data", "user_examples.json")   # sentences YOU corrected

PREFIXES = ["jarvis ", "hey jarvis ", "please ", "can you ", "jarvis please ", "ok jarvis ", "could you ", "jarvis can you "]
SUFFIXES = ["", "", "", " please", " jarvis", " now"]


def load_dataset():
    with open(DATA_FILE, encoding="utf-8") as f:
        raw = json.load(f)
    from modules.dataset_builder import build
    try:                                              # add the corrections you taught Jarvis
        with open(USER_FILE, encoding="utf-8") as f:
            for intent, phrases in json.load(f).items():
                raw.setdefault(intent, []).extend(phrases * 3)
    except Exception:
        pass
    for intent, phrases in build().items():          # add generated sentences
        raw.setdefault(intent, []).extend(phrases)
    texts, labels, seen = [], [], set()
    for intent, phrases in raw.items():
        for p in phrases:
            p = p.lower().strip()
            if (p, intent) not in seen:                # remove duplicates
                seen.add((p, intent))
                texts.append(p)
                labels.append(intent)
    return texts, labels


def augment(texts, labels, per_sample=4, seed=42):
    """Create extra training sentences by adding natural filler words (training data only)."""
    rng = random.Random(seed)
    out_t, out_l = list(texts), list(labels)
    for t, l in zip(texts, labels):
        for _ in range(per_sample):
            out_t.append(rng.choice(PREFIXES) + t + rng.choice(SUFFIXES))
            out_l.append(l)
    return out_t, out_l


def build_pipeline():
    return Pipeline([
        ("features", FeatureUnion([
            ("char", TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 5), sublinear_tf=True)),
            ("word", TfidfVectorizer(analyzer="word", ngram_range=(1, 2), sublinear_tf=True)),
        ])),
        ("mlp", MLPClassifier(hidden_layer_sizes=(256, 128), activation="relu", alpha=1e-3,
                              max_iter=600, early_stopping=False, random_state=42)),
    ])


def add_user_example(text, intent):
    data = {}
    try:
        with open(USER_FILE, encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        pass
    data.setdefault(intent, []).append(text.lower().strip())
    os.makedirs(os.path.dirname(USER_FILE), exist_ok=True)
    with open(USER_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def train(verbose=True, evaluate=True):
    texts, labels = load_dataset()

    acc = None
    if evaluate:
        # 1) hold out 20% of the REAL sentences for testing (never augmented => honest score)
        counts = {l: labels.count(l) for l in set(labels)}
        strat = labels if min(counts.values()) >= 2 else None
        X_tr, X_te, y_tr, y_te = train_test_split(texts, labels, test_size=0.2, stratify=strat, random_state=42)
        X_tr_aug, y_tr_aug = augment(X_tr, y_tr)
        model = build_pipeline()
        model.fit(X_tr_aug, y_tr_aug)
        pred = model.predict(X_te)
        acc = accuracy_score(y_te, pred)

    if verbose and evaluate:
        print(f"Dataset: {len(texts)} sentences, {len(set(labels))} intents")
        print(f"Training samples (after augmentation): {len(X_tr_aug)} | Test samples (held out): {len(X_te)}")
        print(f"\nTEST ACCURACY: {acc * 100:.1f}%\n")
        print(classification_report(y_te, pred, zero_division=0))
        # 2) 5-fold cross-validation on the whole dataset for a second opinion
        cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=7)
        scores = cross_val_score(build_pipeline(), texts, labels, cv=cv)
        print(f"5-fold cross-validation accuracy: {np.mean(scores) * 100:.1f}% (+/- {np.std(scores) * 100:.1f})")

    # 3) final model: learn from ALL data so Jarvis is as smart as possible
    all_t, all_l = augment(texts, labels)
    final = build_pipeline()
    final.fit(all_t, all_l)
    os.makedirs(os.path.dirname(MODEL_FILE), exist_ok=True)
    joblib.dump(final, MODEL_FILE)
    if verbose:
        print(f"\nModel saved to {MODEL_FILE}")
    return acc


class IntentModel:
    def __init__(self):
        if not os.path.exists(MODEL_FILE):
            print("[Jarvis] No trained model found - training the neural network now...")
            train(verbose=False)
        self.model = joblib.load(MODEL_FILE)

    def learn(self, text, intent, on_done=None):
        """Teach Jarvis a correction. Retrains in the background (about 30 seconds)."""
        add_user_example(text, intent)

        def work():
            try:
                train(verbose=False, evaluate=False)
                self.model = joblib.load(MODEL_FILE)
                msg = "I have learned that. I'm smarter now."
            except Exception as e:
                msg = f"I saved your correction but couldn't retrain: {e}"
            if on_done:
                on_done(msg)

        threading.Thread(target=work, daemon=True).start()

    def predict(self, text):
        text = text.lower().strip()
        probs = self.model.predict_proba([text])[0]
        i = int(np.argmax(probs))
        return str(self.model.classes_[i]), float(probs[i])
