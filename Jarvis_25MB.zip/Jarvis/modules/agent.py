"""
Jarvis AGENT - lets Jarvis do real work on your PC by itself.

1. Minecraft builder: Gemini WATCHES your tutorial video (YouTube link or .mp4), designs the build as
   Minecraft commands (/fill, /setblock), Jarvis opens/focuses Minecraft and types them in for you.
2. Screen agent: for any other task, Jarvis looks at the screen with Gemini vision and moves the
   mouse / presses keys step by step until the goal is done.

SAFETY: it asks your permission first, has a step limit, blocks dangerous shortcuts, only allows
safe Minecraft commands, and you can abort at any time by slamming the mouse into the TOP-LEFT corner.
"""
import glob
import io
import json
import os
import re
import subprocess
import time
import zipfile
from datetime import datetime

from google.genai import types

import config

YT = re.compile(r"https?://(?:www\.)?(?:youtube\.com/watch\?\S+|youtu\.be/\S+|youtube\.com/shorts/\S+)")
VIDEO_EXT = (".mp4", ".mov", ".webm", ".mkv", ".avi")
ALLOWED_MC = {"fill", "setblock", "tp", "gamemode", "time", "weather", "clone"}
BLOCKED_HOTKEYS = [{"alt", "f4"}, {"ctrl", "alt", "delete"}, {"win", "r"}, {"ctrl", "shift", "esc"}, {"win", "l"}]
YES = re.compile(r"\b(yes|yeah|yep|sure|ok|okay|go|proceed|confirm|haan|ha|kar do|karo|chalo)\b", re.I)

AGENT_REQUEST = re.compile(
    r"minecraft|follow(ing)? (this |the |that )?video|help of (this |the |that |following )?video|"
    r"control my (pc|computer)|do (this|the) task|automate|use my (pc|computer) to", re.I)

PLAN_SYSTEM = (
    "You are a master Minecraft JAVA EDITION builder who writes in-game commands. "
    "Output ONLY valid JSON: {\"name\": \"short name\", \"commands\": [\"/fill ...\", \"/setblock ...\"]}. "
    "Rules: use ONLY /fill and /setblock (optionally /tp ~ ~ ~ and /gamemode creative). "
    "All coordinates are relative to the player using ~ . Start building 4 blocks away in the +x +z direction "
    "(first corner near ~4 ~-1 ~4), foundation at y ~-1, build upward. Max footprint 45x45, max height 35. "
    "Each /fill must contain at most 32768 blocks. Use real block ids like minecraft:stone_bricks. "
    "At most 90 commands, ordered: foundation, walls (use hollow), corner towers, battlements, roof, gate, windows, details. "
    "If a video is attached, study it carefully (shape, size, towers, walls, gate, roof, materials, colours) and copy that design."
)

STEP_SYSTEM = (
    "You control a Windows PC to achieve the user's GOAL. Each turn you get a screenshot. "
    "Reply ONLY with JSON: {\"thought\": \"...\", \"action\": one of click|double_click|right_click|type|press|hotkey|scroll|wait|done|fail, "
    "\"x\": 0-1000, \"y\": 0-1000 (position on the screenshot, 0,0 = top-left, 1000,1000 = bottom-right), "
    "\"text\": \"text to type\", \"keys\": [\"ctrl\",\"s\"], \"amount\": scroll clicks (negative=down), \"seconds\": wait time}. "
    "Do one small action per turn. Use done when the goal is achieved, fail if impossible. "
    "Never do anything destructive (deleting files, paying, sending messages, changing passwords)."
)


def _json(text):
    text = (text or "").strip()
    text = re.sub(r"^```(?:json)?|```$", "", text, flags=re.M).strip()
    try:
        return json.loads(text)
    except Exception:
        m = re.search(r"\{.*\}", text, re.S)
        return json.loads(m.group(0)) if m else None


def _rel(tok):
    """'~5' -> 5, '~' -> 0, anything not relative -> None."""
    if not tok.startswith("~"):
        return None
    try:
        return int(float(tok[1:] or 0))
    except ValueError:
        return None


def parse_box(cmd):
    """Returns (x1,y1,z1,x2,y2,z2) in relative blocks for /fill and /setblock, else None."""
    parts = cmd.strip().split()
    verb = parts[0][1:].lower().replace("minecraft:", "")
    n = 6 if verb == "fill" else 3 if verb == "setblock" else 0
    if not n or len(parts) < n + 2:
        return None
    nums = [_rel(t) for t in parts[1:n + 1]]
    if None in nums:
        return None
    return tuple(nums) if n == 6 else (nums[0], nums[1], nums[2], nums[0], nums[1], nums[2])


def validate_mc(cmd):
    """Only safe building commands may reach the game (relative coordinates only, size-limited)."""
    cmd = (cmd or "").strip()
    if not cmd.startswith("/") or "\n" in cmd or len(cmd) > 250:
        return False
    verb = cmd[1:].split(" ", 1)[0].lower().replace("minecraft:", "")
    if verb not in ALLOWED_MC:
        return False
    if verb in ("fill", "setblock"):
        b = parse_box(cmd)
        if b is None:
            return False
        vol = (abs(b[3] - b[0]) + 1) * (abs(b[4] - b[1]) + 1) * (abs(b[5] - b[2]) + 1)
        return vol <= 32768
    if verb == "tp":
        return len(cmd.split()) in (1, 4) and all(t.startswith("~") for t in cmd.split()[1:])
    return verb in ("gamemode", "time", "weather")


def preview(cmds, name):
    """Size, block palette and bounding box of a plan, as a spoken summary + raw numbers."""
    boxes = [parse_box(c) for c in cmds if parse_box(c)]
    if not boxes:
        return None
    xs = [v for b in boxes for v in (b[0], b[3])]
    ys = [v for b in boxes for v in (b[1], b[4])]
    zs = [v for b in boxes for v in (b[2], b[5])]
    size = (max(xs) - min(xs) + 1, max(ys) - min(ys) + 1, max(zs) - min(zs) + 1)
    blocks = []
    for c in cmds:
        verb = c[1:].split(" ", 1)[0].lower()
        if verb in ("fill", "setblock"):
            toks = c.split()
            b = toks[7 if verb == "fill" else 4] if len(toks) > (7 if verb == "fill" else 4) else ""
            b = re.sub(r"\[.*$", "", b.replace("minecraft:", ""))
            if b and b != "air" and b not in blocks:
                blocks.append(b)
    return size, blocks[:5]


class Agent:
    def __init__(self, brain, speech, say, status):
        self.brain, self.speech, self.say, self.status = brain, speech, say, status

    @staticmethod
    def is_request(text):
        return bool(AGENT_REQUEST.search(text))

    # ------------------------------------------------------------------ entry
    def run(self, task):
        try:
            import pyautogui  # noqa: F401
            import pyperclip  # noqa: F401
        except ImportError:
            return "I need two more packages. Run: pip install pyautogui pyperclip pillow"
        low = task.lower()
        if "minecraft" in low and re.search(r"build|make|create|construct|castle|house|tower|bana", low):
            return self.minecraft_build(task)
        return self.screen_task(task)

    def _confirm(self, question):
        self.say(question + " Say yes to continue.")
        for _ in range(2):
            if YES.search(self.speech.listen() or ""):
                return True
        return False

    # ---------------------------------------------------------------- video
    def _video_part(self):
        """Finds the tutorial: YouTube link in clipboard, else newest file in the videos folder."""
        try:
            import pyperclip
            m = YT.search(pyperclip.paste() or "")
            if m:
                return types.Part(file_data=types.FileData(file_uri=m.group(0))), "YouTube video from your clipboard"
        except Exception:
            pass
        files = [f for f in glob.glob(os.path.join(config.VIDEO_FOLDER, "*")) if f.lower().endswith(VIDEO_EXT)]
        if files:
            path = max(files, key=os.path.getmtime)
            self.status("Uploading video to Gemini...")
            up = self.brain.client.files.upload(file=path)
            for _ in range(60):                                  # wait until Google finished processing it
                up = self.brain.client.files.get(name=up.name)
                if str(getattr(up.state, "name", up.state)).upper().endswith("ACTIVE"):
                    break
                time.sleep(2)
            return types.Part(file_data=types.FileData(file_uri=up.uri, mime_type=up.mime_type)), os.path.basename(path)
        return None, None

    # ------------------------------------------------------------- Minecraft
    def minecraft_build(self, task):
        video, label = self._video_part()
        if video is None:
            self.say("I couldn't find a video, so I will design it from my own imagination. "
                     "Next time copy a YouTube link or put an mp4 in the videos folder.")
        else:
            self.say(f"Studying {label}. This can take a minute.")

        self.status("Gemini is watching the video and designing the build...")
        parts = ([video] if video else []) + [types.Part(text=f"Task: {task}")]
        raw = self.brain.generate([types.Content(role="user", parts=parts)], PLAN_SYSTEM, deep=True, json_mode=True)
        if not raw:
            return self.brain.last_error
        plan = _json(raw) or {}
        cmds = [c.strip() for c in plan.get("commands", []) if validate_mc(c)][:90]
        if not cmds:
            return "I couldn't turn that into valid building commands. Try a shorter video or a clearer request."
        print("[Agent] Build plan:\n  " + "\n  ".join(cmds))

        info = preview(cmds, plan.get("name", "build"))
        if info is None:
            return "The plan had no building commands, so I stopped."
        (w, hgt, d), blocks = info
        if w > 64 or d > 64 or hgt > 50:
            return f"That plan is too big, {w} by {d} by {hgt} blocks. I stopped to keep your world safe. Ask for something smaller."
        self._save_plan(plan.get("name", "build"), cmds)

        if not self._confirm(f"Preview. The {plan.get('name', 'build')} is about {w} by {d} blocks and {hgt} high, "
                             f"made of {', '.join(blocks) or 'mixed blocks'}, using {len(cmds)} commands. "
                             "Minecraft Java must be open in a creative world with cheats on. "
                             "I will back up your world first. Shall I start?"):
            return "Okay, I cancelled the build."
        self._backup_world()

        self._open_minecraft()
        self.say("Click inside the Minecraft game now. I start in five seconds. "
                 "To stop me, move the mouse to the top left corner.")
        time.sleep(5)
        self._send_commands(["/gamemode creative"] + cmds)
        return f"Finished sending {len(cmds)} commands. Your {plan.get('name', 'build')} should be standing nearby. Look around."

    def _save_plan(self, name, cmds):
        folder = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "builds")
        os.makedirs(folder, exist_ok=True)
        safe = re.sub(r"[^a-z0-9_-]+", "_", name.lower())[:30] or "build"
        with open(os.path.join(folder, f"{safe}_{datetime.now():%Y%m%d_%H%M%S}.txt"), "w", encoding="utf-8") as f:
            f.write("\n".join(cmds))

    def _backup_world(self):
        """Best-effort zip of your most recently played world (skip with BACKUP_WORLD = False)."""
        if not getattr(config, "BACKUP_WORLD", True):
            return
        try:
            saves = getattr(config, "MINECRAFT_SAVES", "") or os.path.join(os.environ.get("APPDATA", ""), ".minecraft", "saves")
            worlds = [os.path.join(saves, w) for w in os.listdir(saves) if os.path.isdir(os.path.join(saves, w))]
            if not worlds:
                self.say("I couldn't find your worlds folder, so no backup. You can set MINECRAFT_SAVES in config dot py.")
                return
            world = max(worlds, key=os.path.getmtime)
            size = sum(os.path.getsize(os.path.join(r, f)) for r, _, fs in os.walk(world) for f in fs if f != "session.lock")
            if size > 1.5 * 1024 ** 3:
                self.say("Your world is bigger than one and a half gigabytes, so I skipped the backup.")
                return
            self.status("Backing up your world...")
            out_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "world_backups")
            os.makedirs(out_dir, exist_ok=True)
            out = os.path.join(out_dir, f"{os.path.basename(world)}_{datetime.now():%Y%m%d_%H%M%S}.zip")
            with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
                for r, _, fs in os.walk(world):
                    for f in fs:
                        if f == "session.lock":
                            continue
                        try:
                            z.write(os.path.join(r, f), os.path.relpath(os.path.join(r, f), saves))
                        except OSError:
                            pass
            files = sorted((os.path.join(out_dir, f) for f in os.listdir(out_dir)), key=os.path.getmtime)
            for f in files[:-3]:                                   # keep only the 3 newest backups
                os.remove(f)
            print(f"[Agent] World backup saved: {out}")
        except Exception as e:
            print(f"[Agent] Backup failed: {e}")
            self.say("The world backup failed, but I will continue.")

    def _open_minecraft(self):
        try:
            import pygetwindow as gw
            wins = [w for w in gw.getWindowsWithTitle("Minecraft") if w.title.strip()]
            if wins:
                wins[0].activate()
                return
        except Exception:
            pass
        if config.MINECRAFT_LAUNCH:
            self.status("Launching Minecraft...")
            subprocess.Popen(f'start "" "{config.MINECRAFT_LAUNCH}"', shell=True)
            self.screen_task("Click Play / Singleplayer and open an existing Creative world with cheats allowed, "
                             "until you are playing inside the world (no menu visible).")

    def _send_commands(self, cmds):
        import pyautogui
        import pyperclip
        for i, c in enumerate(cmds, 1):
            self.status(f"Building... command {i} of {len(cmds)}")
            pyperclip.copy(c)
            pyautogui.press("t")                 # open chat
            time.sleep(0.35)
            pyautogui.hotkey("ctrl", "v")        # paste = reliable for ~ and special characters
            time.sleep(0.15)
            pyautogui.press("enter")
            time.sleep(0.45)
            if i == 3:                           # quick health check: is the game really receiving commands?
                ok, note = self._screen_ok("Minecraft: did the chat commands run? Look for red error text like "
                                           "'Unknown command' or 'Incorrect argument', or a pause/menu screen.")
                if not ok:
                    self.say(f"Something is wrong: {note}. I stopped to be safe.")
                    return

    def _screen_ok(self, question):
        img = self._shot()
        raw = self.brain.generate([types.Content(role="user", parts=[img, types.Part(
            text=question + ' Reply JSON {"ok": true/false, "note": "short reason"}')])],
            "You inspect screenshots.", json_mode=True)
        d = _json(raw) or {}
        return bool(d.get("ok", True)), d.get("note", "")

    # ---------------------------------------------------------- screen agent
    def _shot(self):
        import pyautogui
        im = pyautogui.screenshot()
        im.thumbnail((1280, 1280))
        buf = io.BytesIO()
        im.convert("RGB").save(buf, "JPEG", quality=80)
        return types.Part.from_bytes(data=buf.getvalue(), mime_type="image/jpeg")

    def screen_task(self, goal):
        if not self._confirm(f"I will use the mouse and keyboard to: {goal}. Is that okay?"):
            return "Okay, I won't touch anything."
        self.say("Starting. Move the mouse to the top left corner to stop me.")
        history = []
        for step in range(1, config.AGENT_MAX_STEPS + 1):
            self.status(f"Step {step}: looking at the screen...")
            note = "Previous actions: " + ("; ".join(history[-6:]) or "none")
            raw = self.brain.generate([types.Content(role="user", parts=[
                self._shot(), types.Part(text=f"GOAL: {goal}\n{note}\nWhat is the next single action?")])],
                STEP_SYSTEM, json_mode=True)
            a = _json(raw) if raw else None
            if not a:
                return self.brain.last_error
            act = str(a.get("action", "")).lower()
            print(f"[Agent] step {step}: {a}")
            if act == "done":
                return "Task completed."
            if act == "fail":
                return "I couldn't finish that: " + str(a.get("thought", "not possible"))
            try:
                self._act(a)
            except Exception as e:
                if "FailSafe" in type(e).__name__:
                    return "Stopped, you moved the mouse to the corner."
                history.append(f"error {e}")
            history.append(f"{act} {a.get('text') or a.get('keys') or (a.get('x'), a.get('y'))}")
            time.sleep(1.0)
        return "I reached my step limit, so I stopped. Say the task again to continue."

    def _act(self, a):
        import pyautogui
        w, h = pyautogui.size()
        act = str(a.get("action")).lower()
        if act in ("click", "double_click", "right_click"):
            x = int(float(a.get("x", 500)) / 1000 * w)
            y = int(float(a.get("y", 500)) / 1000 * h)
            if x < 5 and y < 5:
                return                                   # never click the failsafe corner
            pyautogui.moveTo(x, y, duration=0.4)
            {"click": pyautogui.click, "double_click": pyautogui.doubleClick, "right_click": pyautogui.rightClick}[act]()
        elif act == "type":
            pyautogui.write(str(a.get("text", "")), interval=0.03)
        elif act == "press":
            pyautogui.press(str((a.get("keys") or [a.get("text", "enter")])[0]).lower())
        elif act == "hotkey":
            keys = [str(k).lower() for k in a.get("keys", [])]
            if any(b <= set(keys) for b in BLOCKED_HOTKEYS):
                raise RuntimeError("blocked shortcut")
            pyautogui.hotkey(*keys)
        elif act == "scroll":
            pyautogui.scroll(int(a.get("amount", -3)) * 100)
        elif act == "wait":
            time.sleep(min(float(a.get("seconds", 2)), 15))
