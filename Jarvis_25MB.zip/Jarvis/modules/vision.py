"""Jarvis' eyes: look at your screen or your webcam and answer questions with Gemini vision."""
import io
import re

from google.genai import types

import config

SCREEN = re.compile(r"(?:what'?s|what is|what do you see) (?:on|in) (?:my |the )?screen|look at (?:my |the )?screen|read (?:my |the )?screen|screen (?:par|pe|me) kya", re.I)
CAMERA = re.compile(r"what am i holding|what do you see|what is this|look at this|use (?:the |my )?camera|open (?:the |my )?camera|camera (?:me|mein|se) |who is in front|dekho ye kya", re.I)

SYSTEM = ("You are JARVIS. Answer the user's question about the image in 1-3 short spoken sentences. "
          "No markdown, no lists. If the image doesn't show enough to answer, say so.")


class Vision:
    def __init__(self, brain):
        self.brain = brain

    def _ask(self, jpeg_bytes, question):
        part = types.Part.from_bytes(data=jpeg_bytes, mime_type="image/jpeg")
        raw = self.brain.generate([types.Content(role="user", parts=[part, types.Part(text=question)])], SYSTEM)
        return raw or self.brain.last_error

    def screen(self, question):
        try:
            import pyautogui
        except ImportError:
            return "I need pyautogui for that. Run: pip install pyautogui pillow"
        im = pyautogui.screenshot()
        im.thumbnail((1280, 1280))
        buf = io.BytesIO()
        im.convert("RGB").save(buf, "JPEG", quality=80)
        return self._ask(buf.getvalue(), question)

    def camera(self, question):
        try:
            import cv2
        except ImportError:
            return "I need OpenCV for that. Run: pip install opencv-python"
        cap = cv2.VideoCapture(getattr(config, "CAMERA_INDEX", 0))
        try:
            frame = None
            for _ in range(8):               # let the camera auto-adjust its exposure
                ok, frame = cap.read()
            if frame is None or not ok:
                return "I couldn't open the camera. Check CAMERA_INDEX in config dot py."
            ok, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 85])
            return self._ask(buf.tobytes(), question)
        finally:
            cap.release()
