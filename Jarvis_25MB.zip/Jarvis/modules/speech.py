"""Ears (microphone -> text) and mouth (text -> natural voice, can be stopped anytime)."""
import asyncio
import os
import queue
import re
import tempfile
import time
import threading

import pyttsx3
import speech_recognition as sr

import config

SENT_END = re.compile(r"(?<=[.!?\u0964])\s+")

def stream_sentences(chunks):
    """Turns a stream of text pieces into whole sentences, as early as possible (first one can be short)."""
    buf, first = "", True
    for ch in chunks:
        buf += ch
        start = 0
        for m in SENT_END.finditer(buf):
            if m.start() - start >= (12 if first else 25):
                yield buf[start:m.start()].strip()
                first = False
                start = m.end()
        buf = buf[start:]
    if buf.strip():
        yield buf.strip()

_stop = False
_mixer = None
STOP_WORDS = re.compile(r"\b(stop|quiet|enough|shut up|chup|ruko|bas karo|bas|wait|hold on)\b", re.I)


def stop_speaking():
    """Called when you press SPACE or double-click the Jarvis window."""
    global _stop
    _stop = True
    try:
        if _mixer:
            _mixer.music.stop()
    except Exception:
        pass


class _Tap:
    """Wraps the microphone stream so we can read the live volume (for the HUD rings)."""
    def __init__(self, inner, cb):
        self._inner, self._cb = inner, cb

    def read(self, *a, **k):
        data = self._inner.read(*a, **k)
        try:
            self._cb(data)
        except Exception:
            pass
        return data

    def __getattr__(self, name):
        return getattr(self._inner, name)


def list_microphones():
    for i, name in enumerate(sr.Microphone.list_microphone_names()):
        print(f"  [{i}] {name}")


class Speech:
    def __init__(self):
        self.lang = config.LANGUAGE
        self.r = sr.Recognizer()
        self.r.dynamic_energy_threshold = True
        self.r.energy_threshold = 300
        self.r.pause_threshold = getattr(config, "PAUSE_THRESHOLD", 0.6)
        self.r.non_speaking_duration = min(0.4, self.r.pause_threshold)
        self.mic = sr.Microphone(device_index=config.MIC_INDEX)
        self._misses = 0
        self.pending = ""
        self.neural_voice = getattr(config, "USE_NEURAL_VOICE", True)
        self.on_level = None
        self.stt = getattr(config, "STT_ENGINE", "google")
        self._whisper = None
        if self.stt == "whisper":
            self._load_whisper()
        self.calibrate()

    def speak(self, text):
        global _stop
        text = re.sub(r"[*_`#>]", "", text).strip()
        if not text:
            return
        print(f"[Jarvis] {text}")
        self.speak_stream(iter([text]))

    def speak_stream(self, sentences):
        """Speaks sentences as they arrive. While sentence N plays, sentence N+1 is already being made."""
        global _stop
        _stop = False
        use_neural = self.neural_voice and self._ensure_mixer()
        q = queue.Queue(maxsize=2)

        def producer():
            try:
                for s in sentences:
                    if _stop:
                        break
                    s = re.sub(r"[*_`#>]", "", s).strip()
                    if s:
                        q.put((s, self._synth(s) if use_neural else None))
            except Exception as e:
                print(f"[Speech stream error] {e}")
            finally:
                q.put(None)

        threading.Thread(target=producer, daemon=True).start()
        stopper = self._start_barge_in() if use_neural else None
        try:
            while True:
                item = q.get()
                if item is None:
                    break
                s, path = item
                if _stop:
                    self._rm(path)
                elif path:
                    self._play(path)
                else:
                    self._speak_offline(s)
        finally:
            if stopper:
                try:
                    stopper(wait_for_stop=True)
                except Exception:
                    pass

    # ------------------------------------------------------------------ ears
    def calibrate(self):
        with self.mic as source:
            self.r.adjust_for_ambient_noise(source, duration=1.0)
        self.r.energy_threshold = min(max(self.r.energy_threshold, 150), 1500)

    def listen(self):
        """Returns the recognised sentence, or '' if nothing was understood."""
        if self.pending:
            text, self.pending = self.pending, ""
            print(f"[You (interrupted)] {text}")
            return text
        try:
            with self.mic as source:
                real = source.stream
                if self.on_level:
                    source.stream = _Tap(real, self._level)
                try:
                    audio = self.r.listen(source, timeout=6, phrase_time_limit=12)
                finally:
                    source.stream = real
        except sr.WaitTimeoutError:
            self._miss()
            return ""
        except OSError as e:
            print(f"[Mic error] {e}  -> check MIC_INDEX in config.py (python main.py --mics)")
            return ""
        try:
            text = self._transcribe(audio).strip()
            if not text:
                self._miss()
                return ""
            self._misses = 0
            print(f"[You] {text}")
            return text
        except sr.UnknownValueError:
            self._miss()
        except sr.RequestError as e:
            print(f"[Speech service error - check internet] {e}")
        return ""

    def _level(self, data):
        import numpy as np
        a = np.frombuffer(data, dtype=np.int16).astype(np.float32)
        if a.size:
            self.on_level(float(min(1.0, np.sqrt(np.mean(a * a)) / 5000.0)))

    def _load_whisper(self):
        try:
            from faster_whisper import WhisperModel
            name = getattr(config, "WHISPER_MODEL", "small")
            print(f"[Whisper] loading '{name}' model...")
            self._whisper = WhisperModel(name, device="cpu", compute_type="int8")
        except Exception as e:
            print(f"[Whisper unavailable, using Google speech] {e}")
            self.stt = "google"

    def _transcribe(self, audio):
        if self.stt == "whisper" and self._whisper is not None:
            try:
                import numpy as np
                raw = audio.get_raw_data(convert_rate=16000, convert_width=2)
                arr = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
                lang = "hi" if self.lang.startswith("hi") else "en"
                segs, _ = self._whisper.transcribe(arr, language=lang, vad_filter=True, beam_size=1)
                return " ".join(s.text for s in segs).strip()
            except Exception as e:
                print(f"[Whisper error, falling back to Google] {e}")
        return self.r.recognize_google(audio, language=self.lang)

    def _miss(self):
        self._misses += 1
        if self._misses % 8 == 0:
            self.calibrate()

    def _voice_name(self, text):
        hindi = self.lang.startswith("hi") or re.search(r"[\u0900-\u097F]", text)
        if hindi:
            return getattr(config, "TTS_VOICE_HI", "hi-IN-MadhurNeural")
        return getattr(config, "TTS_VOICE_EN", "en-GB-RyanNeural")

    def _ensure_mixer(self):
        global _mixer
        try:
            import edge_tts  # noqa: F401
            os.environ["PYGAME_HIDE_SUPPORT_PROMPT"] = "1"
            import pygame
            if not pygame.mixer.get_init():
                pygame.mixer.init()
            _mixer = pygame.mixer
            return True
        except Exception as e:
            print(f"[Neural voice unavailable, using Windows voice] {e}")
            self.neural_voice = False
            return False

    def _synth(self, text):
        import edge_tts
        fd, path = tempfile.mkstemp(suffix=".mp3")
        os.close(fd)
        try:
            asyncio.run(edge_tts.Communicate(text, self._voice_name(text)).save(path))
            return path
        except Exception as e:
            print(f"[Neural voice failed for this sentence] {e}")
            self._rm(path)
            return None

    def _play(self, path):
        try:
            _mixer.music.load(path)
            _mixer.music.play()
            while _mixer.music.get_busy() and not _stop:
                time.sleep(0.03)
            _mixer.music.stop()
            try:
                _mixer.music.unload()
            except Exception:
                pass
        finally:
            self._rm(path)

    @staticmethod
    def _rm(path):
        if path:
            try:
                os.remove(path)
            except Exception:
                pass

    def _start_barge_in(self):
        mode = getattr(config, "INTERRUPT_MODE", "any_speech")
        if mode == "off":
            return None
        try:
            return self.r.listen_in_background(self.mic, self._barge_callback, phrase_time_limit=6)
        except Exception as e:
            print(f"[Interrupt listener unavailable] {e}")
            return None

    def _barge_callback(self, recognizer, audio):
        try:
            text = recognizer.recognize_google(audio, language=self.lang).strip()
        except Exception:
            return
        self._handle_barge(text)

    def _handle_barge(self, text):
        mode = getattr(config, "INTERRUPT_MODE", "any_speech")
        only_stop = bool(STOP_WORDS.fullmatch(text.strip(" .!").lower())) or len(text.split()) <= 2 and bool(STOP_WORDS.search(text))
        if only_stop:
            stop_speaking()
        elif mode == "any_speech" and text:
            self.pending = text
            stop_speaking()

    def _speak_offline(self, text):
        com = None
        try:
            import pythoncom
            pythoncom.CoInitialize()
            com = pythoncom
        except Exception:
            pass
        try:
            engine = pyttsx3.init()
            engine.setProperty("rate", config.SPEECH_RATE)
            voices = engine.getProperty("voices")
            want = "hindi" if self.lang.startswith("hi") else "english"
            for v in voices:
                if want in v.name.lower() or (want == "hindi" and "hi-in" in str(v.id).lower()):
                    engine.setProperty("voice", v.id)
                    break
            engine.say(text)
            engine.runAndWait()
            engine.stop()
        except Exception as e:
            print(f"[Voice error] {e}")
        finally:
            if com:
                try:
                    com.CoUninitialize()
                except Exception:
                    pass