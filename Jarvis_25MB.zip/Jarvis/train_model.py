"""Run this to train + test the neural network:   python train_model.py"""
from modules.intent_model import train

if __name__ == "__main__":
    train(verbose=True)
